import React, { useEffect, useMemo, useState } from 'react';
import { Eye, EyeOff, Package, Search } from 'lucide-react';
import { INITIAL_PRODUCTION_ORDERS } from '../../data/productionOrdersData';
import { ORDERS_DATABASE } from '../../data/ordersDatabase';
import { EQUIPMENT_ITEMS } from '../../data/initialData';
import { OrderItem } from '../../types/mapping';
import { BaseOrder } from '../../types/orders';
import { ProductionOrder } from '../../types/production';
import { STORAGE_KEYS } from '../../services/productionSyncService';

const PENDING_ORDERS_KEY = 'kiraso_pending_ops';

function readOrders(): ProductionOrder[] {
  const saved = localStorage.getItem(PENDING_ORDERS_KEY);
  if (!saved) return INITIAL_PRODUCTION_ORDERS;

  try {
    const parsed: unknown = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed as ProductionOrder[] : INITIAL_PRODUCTION_ORDERS;
  } catch (error) {
    console.error('Falha ao carregar pedidos do painel:', error);
    return INITIAL_PRODUCTION_ORDERS;
  }
}

function readMappingOrders(): OrderItem[] {
  const saved = localStorage.getItem(STORAGE_KEYS.MAPPING_ORDERS);
  if (!saved) return [];

  try {
    const parsed: unknown = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed as OrderItem[] : [];
  } catch (error) {
    console.error('Falha ao carregar pedidos do Mapeamento:', error);
    return [];
  }
}

export function OrdersDashboardTab() {
  const [orders, setOrders] = useState<ProductionOrder[]>(readOrders);
  const [mappingOrders, setMappingOrders] = useState<OrderItem[]>(readMappingOrders);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

  useEffect(() => {
    const syncFromMapping = () => {
      try {
        const mappedOrders = readMappingOrders();
        if (mappedOrders.length === 0) return;

        const previousOrders = readOrders();
        const previousByNumber = new Map(previousOrders.map((order) => [order.pedido.toLowerCase(), order]));
        const rawDeliveries = localStorage.getItem(STORAGE_KEYS.MAPPING_DELIVERIES);
        const deliveries = rawDeliveries
          ? JSON.parse(rawDeliveries) as Array<{
              linkedOrderId?: string;
              linkedOrderNumber?: string;
              destinoOuPedido?: string;
              quantidade: number;
            }>
          : [];

        const updatedOrders = mappedOrders.map((mappedOrder): ProductionOrder => {
          const previousOrder = previousByNumber.get(mappedOrder.numPed.toLowerCase());
          const delivered = deliveries
            .filter((delivery) =>
              delivery.linkedOrderId === mappedOrder.id ||
              delivery.linkedOrderNumber?.toLowerCase() === mappedOrder.numPed.toLowerCase() ||
              (delivery.destinoOuPedido || '').toLowerCase().includes(mappedOrder.numPed.toLowerCase())
            )
            .reduce((sum, delivery) => sum + (Number(delivery.quantidade) || 0), 0);
          const total = Number(mappedOrder.quantidade) || 0;
          const destined = delivered || mappedOrder.destinadoProducao || 0;

          return {
            id: previousOrder?.id || `op-${mappedOrder.id}`,
            prioridade: previousOrder?.prioridade || 'Padrão',
            ordem: previousOrder?.ordem || `OP-${mappedOrder.numPed}`,
            origem: previousOrder?.origem || 'Pedido de Venda',
            tipoOrigemBadge: previousOrder?.tipoOrigemBadge || mappedOrder.tipoNegocio || 'Pedido',
            clienteSolicitante: mappedOrder.cliente,
            pedido: mappedOrder.numPed,
            itemModel: mappedOrder.modeloDesc ||
              EQUIPMENT_ITEMS.find((item) => item.id === mappedOrder.itemId)?.name ||
              mappedOrder.itemId,
            produzido: Math.min(previousOrder?.produzido || 0, total),
            falta: Math.max(0, total - (previousOrder?.produzido || 0)),
            totalQtd: total,
            destinado: Math.min(total, destined),
            dataCriacao: previousOrder?.dataCriacao || mappedOrder.dataEnvio || '',
            status: 'A atender',
            bancada: previousOrder?.bancada || 'Bancada 01',
            observacoes: mappedOrder.observacao || previousOrder?.observacoes,
          };
        });

        localStorage.setItem(PENDING_ORDERS_KEY, JSON.stringify(updatedOrders));
        setOrders(updatedOrders);
        setMappingOrders(mappedOrders);
      } catch (error) {
        console.error('Falha ao sincronizar pedidos do Mapeamento:', error);
      }
    };

    const refreshOrders = () => {
      setOrders(readOrders());
      setMappingOrders(readMappingOrders());
    };

    window.addEventListener('kiraso_orders_sync', refreshOrders);
    window.addEventListener('kiraso_mapping_state_sync', syncFromMapping);
    window.addEventListener('storage', refreshOrders);
    syncFromMapping();

    return () => {
      window.removeEventListener('kiraso_orders_sync', refreshOrders);
      window.removeEventListener('kiraso_mapping_state_sync', syncFromMapping);
      window.removeEventListener('storage', refreshOrders);
    };
  }, []);

  const filteredOrders = useMemo(() => {
    const query = searchQuery.trim().toLocaleLowerCase('pt-BR');
    if (!query) return orders;

    return orders.filter((order) => {
      const mappedOrder = mappingOrders.find((candidate) =>
        candidate.numPed.toLowerCase() === order.pedido.toLowerCase()
      );
      const baseOrder = ORDERS_DATABASE.find((candidate) =>
        candidate.numPedido.toLowerCase() === order.pedido.toLowerCase()
      );
      return [
        order.ordem,
        order.pedido,
        order.clienteSolicitante,
        order.itemModel,
        order.origem,
        mappedOrder?.observacao,
        baseOrder?.comercial,
        baseOrder?.geracao,
        baseOrder?.operadora,
        mappedOrder?.comercial,
        mappedOrder?.geracao,
        mappedOrder?.operadora,
      ].some((value) => value?.toLocaleLowerCase('pt-BR').includes(query));
    });
  }, [orders, mappingOrders, searchQuery]);

  const totalQuantity = orders.reduce((sum, order) => sum + (Number(order.totalQtd) || 0), 0);

  const getOrderData = (order: ProductionOrder) => {
    const mappedOrder = mappingOrders.find((candidate) =>
      candidate.numPed.toLowerCase() === order.pedido.toLowerCase()
    );
    const baseOrder: BaseOrder | undefined = ORDERS_DATABASE.find((candidate) =>
      candidate.numPedido.toLowerCase() === order.pedido.toLowerCase()
    );

    return { mappedOrder, baseOrder };
  };

  const formatDate = (date: string) => {
    if (!date) return '—';
    const localizedDate = date.match(/^(\d{2}\/\d{2}\/\d{4})/);
    if (localizedDate) return localizedDate[1];

    const isoDate = date.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (isoDate) return `${isoDate[3]}/${isoDate[2]}/${isoDate[1]}`;

    const parsedDate = new Date(date);
    return Number.isNaN(parsedDate.getTime()) ? date : parsedDate.toLocaleDateString('pt-BR');
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Painel de Pedidos</h1>
          <p className="mt-1 text-sm text-gray-500">Pedidos atualizados e sincronizados com o Mapeamento.</p>
        </div>
        <div className="flex gap-3">
          <div className="rounded-lg border border-gray-200 bg-white px-4 py-2">
            <span className="block text-[11px] font-medium uppercase text-gray-500">Pedidos</span>
            <span className="text-lg font-bold text-slate-900">{orders.length}</span>
          </div>
          <div className="rounded-lg border border-gray-200 bg-white px-4 py-2">
            <span className="block text-[11px] font-medium uppercase text-gray-500">Unidades</span>
            <span className="text-lg font-bold text-slate-900">{totalQuantity.toLocaleString('pt-BR')}</span>
          </div>
        </div>
      </div>

      <div className="relative max-w-xl">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <input
          type="search"
          value={searchQuery}
          onChange={(event) => setSearchQuery(event.target.value)}
          placeholder="Buscar por pedido, cliente, modelo ou operadora..."
          className="w-full rounded-lg border border-gray-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
        />
      </div>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1050px] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-gray-200 bg-slate-50 text-[10px] font-semibold uppercase tracking-wider text-gray-500">
                <th className="px-4 py-3">Data</th>
                <th className="px-3 py-3">Nº do pedido</th>
                <th className="px-3 py-3">Cliente</th>
                <th className="px-3 py-3 text-center">Quantidade</th>
                <th className="px-3 py-3">Modelo</th>
                <th className="px-3 py-3">Geração</th>
                <th className="px-3 py-3">Operadora</th>
                <th className="px-3 py-3">Carregador</th>
                <th className="px-4 py-3 text-right">Detalhes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-sm text-gray-500">
                    {orders.length === 0 ? 'Nenhum pedido disponível.' : 'Nenhum pedido encontrado.'}
                  </td>
                </tr>
              ) : filteredOrders.map((order) => {
                const isExpanded = expandedOrderId === order.id;
                const { mappedOrder, baseOrder } = getOrderData(order);
                const model = baseOrder?.modeloVariacao || mappedOrder?.modeloDesc || order.itemModel;
                const generation = baseOrder?.geracao || mappedOrder?.geracao || '—';
                const operator = baseOrder?.operadora || mappedOrder?.operadora || '—';
                const charger = baseOrder?.carregador || mappedOrder?.carregador || '—';

                return (
                  <React.Fragment key={order.id}>
                    <tr className="hover:bg-slate-50">
                      <td className="whitespace-nowrap px-4 py-3 text-slate-600">
                        {formatDate(baseOrder?.dataSolicitacao || order.dataCriacao)}
                      </td>
                      <td className="whitespace-nowrap px-3 py-3 font-mono font-semibold text-slate-900">
                        {order.pedido}
                      </td>
                      <td className="max-w-[220px] truncate px-3 py-3 text-slate-700">
                        {baseOrder?.cliente || order.clienteSolicitante}
                      </td>
                      <td className="px-3 py-3 text-center font-semibold text-slate-800">
                        {Number(order.totalQtd || 0).toLocaleString('pt-BR')}
                      </td>
                      <td className="max-w-[190px] truncate px-3 py-3 text-slate-700">{model}</td>
                      <td className="px-3 py-3 text-slate-700">{generation}</td>
                      <td className="px-3 py-3 text-slate-700">{operator}</td>
                      <td className="px-3 py-3 text-slate-500">{charger}</td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                          aria-expanded={isExpanded}
                          className="inline-flex items-center gap-1.5 rounded-md border border-blue-200 px-2.5 py-1.5 font-semibold text-blue-700 hover:bg-blue-50"
                        >
                          {isExpanded ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                          {isExpanded ? 'Fechar' : 'Ver detalhes'}
                        </button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-slate-50/70">
                        <td colSpan={9} className="px-5 py-4">
                          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-800">
                            <Package className="h-4 w-4 text-blue-600" />
                            Informações completas do pedido
                          </div>
                          <dl className="grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2 lg:grid-cols-4">
                            {[
                              ['Nº da ordem', order.ordem],
                              ['Pedido', order.pedido],
                              ['Cliente', baseOrder?.cliente || order.clienteSolicitante],
                              ['CNPJ', baseOrder?.cnpj || mappedOrder?.cnpj],
                              ['Data da solicitação', baseOrder?.dataSolicitacao || mappedOrder?.dataSolicitacao || order.dataCriacao],
                              ['Data de envio', baseOrder?.dataEnvio || mappedOrder?.dataEnvio],
                              ['Quantidade', String(order.totalQtd)],
                              ['Modelo', model],
                              ['Geração', generation],
                              ['Operadora', operator],
                              ['Tipo de item', baseOrder?.tipoItem || mappedOrder?.tipoItem],
                              ['Variação', baseOrder?.corVariacao || mappedOrder?.corVariacao || mappedOrder?.modeloVariacao],
                              ['Tipo de negócio', baseOrder?.tipoNegocio || mappedOrder?.tipoNegocio],
                              ['Tipo de entrega', baseOrder?.tipoEntrega || mappedOrder?.tipoEntrega],
                              ['Comercial', baseOrder?.comercial || mappedOrder?.comercial],
                              ['Contrato', baseOrder?.contrato || mappedOrder?.contrato],
                              ['Carregador', charger],
                              ['Quantidade de carregadores', String(baseOrder?.quantidadeCarregador || mappedOrder?.quantidadeCarregador || '')],
                              ['Peças destinadas', String(Math.min(order.destinado || 0, order.totalQtd))],
                              ['Observações', mappedOrder?.observacao || baseOrder?.observacao || order.observacoes],
                            ].map(([label, value]) => (
                              <div key={label}>
                                <dt className="text-[11px] font-medium uppercase text-gray-500">{label}</dt>
                                <dd className="mt-0.5 break-words text-sm text-slate-800">{value || 'Não informado'}</dd>
                              </div>
                            ))}
                          </dl>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
