# Mapeamento de Produção & Estoque

Aplicação web para mapeamento de estoque, pedidos comprometidos e entregas de equipamentos para produção.

## Desenvolvimento local

Requisitos: Node.js 22 ou superior.

```bash
npm ci
npm run dev
```

## Publicação permanente no GitHub Pages

O workflow em `.github/workflows/deploy.yml` compila e publica o site automaticamente no GitHub Pages quando há um push para `main` ou `master`. Também é possível iniciar a publicação manualmente pela aba **Actions**.

1. Envie este projeto para um repositório no GitHub.
2. No repositório, acesse **Settings → Pages** e escolha **GitHub Actions** como origem da publicação.
3. Aguarde a conclusão do workflow **Deploy to GitHub Pages** na aba **Actions**.
4. Acesse o endereço exibido em **Settings → Pages**. O site publicado é público para qualquer pessoa com o link.

O workflow gera os arquivos estáticos em `dist` e os hospeda no GitHub Pages; o site não depende de um computador ou túnel local ligado. Cada pessoa usa o armazenamento local do próprio navegador, então alterações de dados feitas por uma pessoa não são compartilhadas automaticamente com os demais visitantes.
