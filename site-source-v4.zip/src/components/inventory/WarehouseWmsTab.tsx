import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { ArrowDownToLine, ArrowLeftRight, Barcode, Boxes, ClipboardMinus, Factory, MapPin, PackagePlus, Search } from 'lucide-react';
import { WMS_INITIAL_STOCK } from '../../data/wmsSeed';
import { INITIAL_IN_PROGRESS_ORDERS, INITIAL_PRODUCTION_ORDERS } from '../../data/productionOrdersData';
import type { ProductionOrder } from '../../types/production';

type Unit = 'UN' | 'MT';
type MovementKind = 'baixa' | 'transferencia' | 'saida_producao';

type InventoryEntry = {
  id: string;
  location: string;
  itemCode: string;
  itemName: string;
  lot: string;
  boxCount: number;
  quantity: number | null;
  rawQuantity: string;
  unit: Unit;
  status: string;
  serialized: boolean;
  serials: string[];
  supplier: string;
  invoiceNumber: string;
  receivedDate: string;
  barcode: string;
};

type StockMovement = {
  id: string;
  date: string;
  kind: MovementKind;
  itemCode: string;
  itemName: string;
  lot: string;
  locationFrom: string;
  locationTo: string;
  quantity: number;
  unit: Unit;
  reference: string;
  serials: string[];
  wallBarcode: string;
  productionOrderCode: string;
};

type WmsData = { entries: InventoryEntry[]; movements: StockMovement[] };

const STORAGE_KEY = 'kiraso_wms_inventory_v2';
const LEGACY_STORAGE_KEY = 'kiraso_wms_plps_v1';
const EMPTY_DATA: WmsData = { entries: [], movements: [] };

function createSeedEntries(): InventoryEntry[] {
  return WMS_INITIAL_STOCK.map((row, index) => ({
    id: `base-${index + 1}`,
    location: row.location,
    itemCode: row.sku,
    itemName: row.itemName,
    lot: row.lot,
    boxCount: row.boxCount,
    quantity: row.quantity,
    rawQuantity: row.rawQuantity,
    unit: row.unit,
    status: row.status,
    serialized: false,
    serials: [],
    supplier: '',
    invoiceNumber: '',
    receivedDate: '',
    barcode: row.lot,
  }));
}

function normalizeData(value: Partial<WmsData>): WmsData {
  return {
    entries: (value.entries ?? []).map((entry) => ({
      ...entry,
      boxCount: entry.boxCount ?? 0,
      quantity: entry.quantity ?? null,
      rawQuantity: entry.rawQuantity ?? String(entry.quantity ?? ''),
      unit: entry.unit ?? 'UN',
      status: entry.status ?? 'ARMAZENADO',
      serialized: entry.serialized ?? false,
      serials: entry.serials ?? [],
      supplier: entry.supplier ?? '',
      invoiceNumber: entry.invoiceNumber ?? '',
      receivedDate: entry.receivedDate ?? '',
      barcode: entry.barcode ?? '',
    })),
    movements: (value.movements ?? []).map((movement) => ({
      ...movement,
      kind: movement.kind ?? 'baixa',
      locationFrom: movement.locationFrom ?? movement.location ?? '',
      locationTo: movement.locationTo ?? '',
      reference: movement.reference ?? '',
      unit: movement.unit ?? 'UN',
      serials: movement.serials ?? [],
      wallBarcode: movement.wallBarcode ?? '',
      productionOrderCode: movement.productionOrderCode ?? '',
    })),
  };
}

function readData(): WmsData {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return normalizeData(JSON.parse(saved) as Partial<WmsData>);

    const legacySaved = localStorage.getItem(LEGACY_STORAGE_KEY);
    const legacy = legacySaved ? JSON.parse(legacySaved) as {
      plps?: Array<{ id: string; barcode: string; boxes?: Array<{
        id: string; barcode?: string; itemCode: string; itemName: string; quantity: number;
        serials?: string[]; serialized?: boolean; supplier?: string; invoiceNumber?: string;
        receivedDate?: string; location?: string;
      }> }>;
      movements?: Array<{ id: string; date: string; plpBarcode: string; boxBarcode?: string;
        itemName: string; quantity: number; serials?: string[] }>;
    } : null;
    const legacyData = legacy ? normalizeData({
      entries: (legacy.plps ?? []).flatMap((plp) => (plp.boxes ?? []).map((box) => ({
        id: box.id,
        location: box.location || 'SEM POSIÇÃO',
        itemCode: box.itemCode,
        itemName: box.itemName,
        lot: plp.barcode,
        boxCount: box.quantity > 0 ? 1 : 0,
        quantity: box.quantity,
        rawQuantity: String(box.quantity),
        unit: 'UN' as const,
        status: box.quantity > 0 ? 'ARMAZENADO' : 'BAIXADO',
        serialized: box.serialized ?? false,
        serials: box.serials ?? [],
        supplier: box.supplier ?? '',
        invoiceNumber: box.invoiceNumber ?? '',
        receivedDate: box.receivedDate ?? '',
        barcode: box.barcode ?? '',
      }))),
      movements: (legacy.movements ?? []).map((movement) => ({
        id: movement.id, date: movement.date, kind: 'baixa' as const, itemCode: '',
        itemName: movement.itemName, lot: movement.plpBarcode,
        locationFrom: '', locationTo: '', quantity: movement.quantity, unit: 'UN' as const,
        reference: 'Baixa anterior', serials: movement.serials ?? [], wallBarcode: '', productionOrderCode: '',
      })),
    }) : EMPTY_DATA;

    return { entries: [...createSeedEntries(), ...legacyData.entries], movements: legacyData.movements };
  } catch {
    return { entries: createSeedEntries(), movements: [] };
  }
}

function parseSerials(value: string) {
  return value.split(/[\n,;]+/).map((serial) => serial.trim()).filter(Boolean);
}

function formatQuantity(value: number, unit: Unit) {
  return `${value.toLocaleString('pt-BR', { maximumFractionDigits: unit === 'MT' ? 3 : 0 })} ${unit}`;
}

function isValidQuantity(value: number, unit: Unit) {
  return Number.isFinite(value) && value > 0 && (unit === 'MT' || Number.isInteger(value));
}

function normalizeBarcode(value: string) {
  return value.trim().replace(/\s+/g, '').toLocaleUpperCase('pt-BR');
}

function readProductionOrders(): ProductionOrder[] {
  try {
    const pending = localStorage.getItem('kiraso_pending_ops');
    const active = localStorage.getItem('kiraso_active_ops');
    const pendingOrders = pending ? JSON.parse(pending) as ProductionOrder[] : [];
    const activeOrders = active ? JSON.parse(active) as ProductionOrder[] : [];
    const allOrders = [...INITIAL_PRODUCTION_ORDERS, ...INITIAL_IN_PROGRESS_ORDERS, ...pendingOrders, ...activeOrders];
    const uniqueOrders = new Map<string, ProductionOrder>();
    allOrders.forEach((order) => {
      const key = normalizeBarcode(order.ordem || order.pedido || order.id);
      if (key) uniqueOrders.set(key, order);
    });
    return [...uniqueOrders.values()];
  } catch {
    return [...INITIAL_PRODUCTION_ORDERS, ...INITIAL_IN_PROGRESS_ORDERS];
  }
}

function ProductionIssuePanel({ data, onSave }: { data: WmsData; onSave: (next: WmsData, message?: string) => void }) {
  const [lpnBarcode, setLpnBarcode] = useState('');
  const [wallBarcode, setWallBarcode] = useState('');
  const [entryId, setEntryId] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [serialInput, setSerialInput] = useState('');
  const [notice, setNotice] = useState('');
  const lpnInputRef = useRef<HTMLInputElement>(null);
  const wallInputRef = useRef<HTMLInputElement>(null);
  const quantityInputRef = useRef<HTMLInputElement>(null);
  const lastLookedUpLpn = useRef('');

  const lpnMatches = useMemo(() => {
    const scanned = normalizeBarcode(lpnBarcode);
    if (!scanned) return [];
    return data.entries.filter((entry) =>
      normalizeBarcode(entry.lot) === scanned || normalizeBarcode(entry.barcode) === scanned,
    );
  }, [data.entries, lpnBarcode]);
  const lpnStatus = useMemo(() => {
    if (!lpnMatches.length) return null;
    const pendingCount = lpnMatches.filter((entry) => entry.quantity == null).length;
    const availableEntries = lpnMatches.filter((entry) => entry.quantity != null && entry.quantity > 0);
    const totalUnits = lpnMatches.reduce((total, entry) => total + (entry.unit === 'UN' ? entry.quantity ?? 0 : 0), 0);
    const totalMeters = lpnMatches.reduce((total, entry) => total + (entry.unit === 'MT' ? entry.quantity ?? 0 : 0), 0);
    const status = pendingCount
      ? availableEntries.length ? 'PARCIAL · CONFERÊNCIA PENDENTE' : 'PENDENTE DE CONFERÊNCIA'
      : availableEntries.length ? 'ARMAZENADO' : 'BAIXADO';
    return { status, pendingCount, availableEntries, totalUnits, totalMeters };
  }, [lpnMatches]);
  const selectedEntry = lpnMatches.find((entry) => entry.id === entryId);
  const productionOrders = useMemo(readProductionOrders, [wallBarcode]);
  const normalizedWallCode = normalizeBarcode(wallBarcode);
  const linkedOrder = productionOrders.find((order) => [order.ordem, order.pedido, order.id]
    .some((code) => normalizeBarcode(code) === normalizedWallCode));

  const lookupLpn = (value: string) => {
    const scanned = value.trim();
    const normalized = normalizeBarcode(scanned);
    if (!normalized || normalized === lastLookedUpLpn.current) return;
    lastLookedUpLpn.current = normalized;
    const matches = data.entries.filter((entry) =>
      normalizeBarcode(entry.lot) === normalized || normalizeBarcode(entry.barcode) === normalized,
    );
    setLpnBarcode(scanned);
    setEntryId(matches.length === 1 ? matches[0].id : '');
    setQuantity('1');
    setSerialInput('');
    if (matches.length === 0) setNotice(`LPN ${scanned} não encontrada no WMS.`);
    else if (matches.length === 1 && matches[0].quantity == null) setNotice('LPN encontrada, mas a quantidade dessa linha precisa ser conferida no estoque.');
    else if (matches.length === 1) setNotice(`LPN encontrada: ${matches[0].itemName} · ${matches[0].quantity} ${matches[0].unit} em ${matches[0].location}.`);
    else setNotice(`LPN encontrada em ${matches.length} linhas. Selecione a posição/lote correto.`);
    if (matches.length > 0) wallInputRef.current?.focus();
  };

  useEffect(() => {
    const scanned = lpnBarcode.trim();
    const normalized = normalizeBarcode(scanned);
    if (!normalized || normalized === lastLookedUpLpn.current) return;
    const timeoutId = window.setTimeout(() => lookupLpn(scanned), 250);
    return () => window.clearTimeout(timeoutId);
  }, [lpnBarcode, data.entries]);

  const registerOutput = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!lpnBarcode.trim() || !wallBarcode.trim()) {
      setNotice('Bipe a LPN e o código da parede antes de confirmar a saída.');
      return;
    }
    if (!selectedEntry || selectedEntry.quantity == null || selectedEntry.quantity <= 0) {
      setNotice('Selecione uma linha da LPN com saldo conferido e disponível.');
      return;
    }
    const serials = selectedEntry.serialized ? parseSerials(serialInput) : [];
    const issueQuantity = selectedEntry.serialized ? serials.length : Number(quantity);
    if (!isValidQuantity(issueQuantity, selectedEntry.unit) || issueQuantity > selectedEntry.quantity) {
      setNotice(`Saldo disponível nessa posição: ${formatQuantity(selectedEntry.quantity, selectedEntry.unit)}.`);
      return;
    }
    if (selectedEntry.serialized && (
      new Set(serials).size !== serials.length || serials.some((serial) => !selectedEntry.serials.includes(serial))
    )) {
      setNotice('Use somente seriais disponíveis nessa LPN, sem repetição.');
      return;
    }

    const remaining = selectedEntry.quantity - issueQuantity;
    const entries = data.entries.map((entry) => entry.id !== selectedEntry.id ? entry : {
      ...entry,
      quantity: remaining,
      rawQuantity: String(remaining),
      boxCount: remaining === 0 ? 0 : entry.boxCount,
      serials: entry.serials.filter((serial) => !serials.includes(serial)),
      status: remaining === 0 ? 'BAIXADO' : entry.status,
    });
    const movement: StockMovement = {
      id: crypto.randomUUID(), date: new Date().toISOString(), kind: 'saida_producao',
      itemCode: selectedEntry.itemCode, itemName: selectedEntry.itemName, lot: selectedEntry.lot,
      locationFrom: selectedEntry.location, locationTo: 'PRODUÇÃO', quantity: issueQuantity,
      unit: selectedEntry.unit, reference: linkedOrder?.ordem || `Parede ${wallBarcode.trim()}`,
      serials, wallBarcode: wallBarcode.trim(), productionOrderCode: linkedOrder?.ordem ?? '',
    };
    onSave({ entries, movements: [movement, ...data.movements] }, 'Saída da produção registrada no WMS.');
    setNotice(`${formatQuantity(issueQuantity, selectedEntry.unit)} baixado(s) da LPN ${selectedEntry.lot}${linkedOrder ? ` para ${linkedOrder.ordem}` : ''}.`);
    setQuantity('1');
    setSerialInput('');
    setEntryId('');
    setWallBarcode('');
    setLpnBarcode('');
    lastLookedUpLpn.current = '';
    window.setTimeout(() => lpnInputRef.current?.focus(), 0);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 border-b border-gray-200 pb-3"><Factory className="h-5 w-5 text-emerald-700" /><div><h2 className="text-base font-semibold text-slate-900">Saída de materiais para produção</h2><p className="text-xs text-gray-500">A baixa será feita no saldo do WMS e ficará vinculada ao código lido na parede.</p></div></div>
      <form onSubmit={registerOutput} className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <section className="space-y-3 rounded-lg border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2"><Barcode className="h-4 w-4 text-blue-700" /><h3 className="text-sm font-semibold text-slate-900">1. LPN do estoque</h3></div>
          <label className="block text-xs font-medium text-gray-600">Bipe o código de barras da LPN
            <input ref={lpnInputRef} autoFocus value={lpnBarcode} onChange={(event) => setLpnBarcode(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); lookupLpn(event.currentTarget.value); } }} placeholder="A leitura do bipador aparece aqui" className="mt-1 w-full rounded border border-gray-300 px-3 py-2.5 font-mono text-base" />
          </label>
          {lpnStatus && <div role="status" className={`rounded border p-3 ${lpnStatus.pendingCount ? 'border-amber-200 bg-amber-50' : lpnStatus.availableEntries.length ? 'border-emerald-200 bg-emerald-50' : 'border-gray-200 bg-gray-50'}`}><div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-medium text-gray-600">Status da LPN</span><span className={`text-xs font-bold ${lpnStatus.pendingCount ? 'text-amber-800' : lpnStatus.availableEntries.length ? 'text-emerald-800' : 'text-gray-600'}`}>{lpnStatus.status}</span></div><div className="mt-1 text-sm font-semibold text-slate-900">{lpnStatus.totalUnits > 0 ? formatQuantity(lpnStatus.totalUnits, 'UN') : ''}{lpnStatus.totalUnits > 0 && lpnStatus.totalMeters > 0 ? ' · ' : ''}{lpnStatus.totalMeters > 0 ? formatQuantity(lpnStatus.totalMeters, 'MT') : ''}{lpnStatus.totalUnits === 0 && lpnStatus.totalMeters === 0 ? 'Sem saldo conferido' : ' disponíveis'}</div><div className="mt-1 text-xs text-gray-600">{lpnMatches.length} registro(s) · {new Set(lpnMatches.map((entry) => entry.location)).size} posição(ões){lpnStatus.pendingCount ? ` · ${lpnStatus.pendingCount} quantidade(s) pendente(s)` : ''}</div></div>}
          {lpnMatches.length > 1 && <label className="block text-xs font-medium text-gray-600">Escolha o saldo de origem
            <select required value={entryId} onChange={(event) => setEntryId(event.target.value)} className="mt-1 w-full rounded border border-gray-300 bg-white px-2.5 py-2 text-sm"><option value="">Selecione posição e saldo</option>{lpnMatches.map((entry) => <option key={entry.id} value={entry.id}>{entry.location} · SKU {entry.itemCode} · {entry.quantity == null ? `Conferir ${entry.rawQuantity}` : formatQuantity(entry.quantity, entry.unit)}</option>)}</select>
          </label>}
          {selectedEntry && <div className={`rounded border p-3 text-sm ${selectedEntry.quantity == null ? 'border-amber-200 bg-amber-50' : 'border-emerald-200 bg-emerald-50'}`}><div className="font-semibold text-slate-900">{selectedEntry.itemName} · SKU {selectedEntry.itemCode}</div><div className="mt-1 text-xs text-slate-700">Lote {selectedEntry.lot} · posição {selectedEntry.location}</div><div className="mt-1 font-semibold text-slate-800">{selectedEntry.quantity == null ? `Quantidade a conferir: ${selectedEntry.rawQuantity}` : `Disponível: ${formatQuantity(selectedEntry.quantity, selectedEntry.unit)}`}</div>{selectedEntry.quantity == null && <div className="mt-1 text-xs text-amber-800">A saída está bloqueada até a conferência do saldo na aba Posições e estoque.</div>}</div>}
          {!selectedEntry && lpnBarcode && lpnMatches.length === 0 && <p className="rounded bg-amber-50 p-3 text-xs text-amber-800">LPN não localizada. Confira o código ou registre a entrada no WMS.</p>}
        </section>

        <section className="space-y-3 rounded-lg border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2"><Barcode className="h-4 w-4 text-emerald-700" /><h3 className="text-sm font-semibold text-slate-900">2. Parede de produção</h3></div>
          <label className="block text-xs font-medium text-gray-600">Bipe o código de baixa da parede
            <input ref={wallInputRef} required value={wallBarcode} onChange={(event) => setWallBarcode(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); quantityInputRef.current?.focus(); } }} placeholder="Código da OP, pedido ou parede" className="mt-1 w-full rounded border border-gray-300 px-3 py-2.5 font-mono text-base" />
          </label>
          {linkedOrder ? <div className="rounded border border-blue-200 bg-blue-50 p-3 text-xs text-blue-950"><div className="font-semibold">OP reconhecida: {linkedOrder.ordem}</div><div className="mt-1">Pedido {linkedOrder.pedido} · {linkedOrder.itemModel} · {linkedOrder.clienteSolicitante}</div><div className="mt-1 text-blue-800">A baixa de material será registrada no WMS; esta leitura não finaliza a OP.</div></div> : wallBarcode.trim() ? <div className="rounded border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">Código de parede será registrado como referência. Não há OP/PV com este código cadastrado.</div> : <p className="rounded bg-slate-50 p-3 text-xs text-gray-500">A OP ou o pedido será identificado automaticamente se o código corresponder a uma ordem cadastrada.</p>}
          {selectedEntry && selectedEntry.quantity != null && selectedEntry.quantity > 0 && (selectedEntry.serialized ? <label className="block text-xs font-medium text-gray-600">Seriais que sairão
            <textarea required rows={4} value={serialInput} onChange={(event) => setSerialInput(event.target.value)} placeholder="Bipe ou informe os seriais, um por linha" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /><span className="mt-1 block font-normal text-gray-400">Disponíveis: {selectedEntry.serials.join(', ')}</span>
          </label> : <label className="block text-xs font-medium text-gray-600">Quantidade para a produção
            <input ref={quantityInputRef} required type="number" min="0.001" max={selectedEntry.quantity} step={selectedEntry.unit === 'MT' ? '0.001' : '1'} value={quantity} onChange={(event) => setQuantity(event.target.value)} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" />
          </label>)}
          <button type="submit" disabled={!selectedEntry || selectedEntry.quantity == null || selectedEntry.quantity <= 0 || lpnMatches.length > 1 && !entryId} className="inline-flex items-center gap-2 rounded bg-emerald-700 px-3.5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-50"><ClipboardMinus className="h-4 w-4" />Confirmar baixa de produção</button>
        </section>
      </form>
      {notice && <div role="status" className="border-l-4 border-blue-600 bg-blue-50 px-3 py-2 text-xs text-blue-900">{notice}</div>}
    </div>
  );
}

export function WarehouseWmsTab({ initialView = 'stock' }: { initialView?: 'stock' | 'production' }) {
  const [data, setData] = useState<WmsData>(readData);
  const [notice, setNotice] = useState('');
  const [activeView, setActiveView] = useState<'stock' | 'production'>(initialView);
  const [query, setQuery] = useState('');
  const [inbound, setInbound] = useState({
    location: '', itemCode: '', itemName: '', lot: '', boxCount: '1', quantity: '1', unit: 'UN' as Unit,
    mode: 'quantity' as 'quantity' | 'serialized', serials: '', supplier: '', invoiceNumber: '', receivedDate: '',
  });
  const [movementForm, setMovementForm] = useState({
    kind: 'baixa' as MovementKind, entryId: '', quantity: '1', destination: '', reference: '', serials: '',
  });
  const [serialEntryId, setSerialEntryId] = useState('');
  const [serialInput, setSerialInput] = useState('');

  const selectedEntry = data.entries.find((entry) => entry.id === movementForm.entryId);
  const filteredEntries = useMemo(() => {
    const term = query.trim().toLocaleLowerCase('pt-BR');
    if (!term) return data.entries;
    return data.entries.filter((entry) => [entry.location, entry.itemCode, entry.itemName, entry.lot, entry.status]
      .some((value) => value.toLocaleLowerCase('pt-BR').includes(term)));
  }, [data.entries, query]);

  const positions = useMemo(() => {
    const summary = new Map<string, { rows: number; boxes: number; units: number; meters: number; pending: number }>();
    data.entries.forEach((entry) => {
      const current = summary.get(entry.location) ?? { rows: 0, boxes: 0, units: 0, meters: 0, pending: 0 };
      current.rows += 1;
      current.boxes += entry.boxCount;
      if (entry.quantity == null) current.pending += 1;
      else if (entry.unit === 'MT') current.meters += entry.quantity;
      else current.units += entry.quantity;
      summary.set(entry.location, current);
    });
    return [...summary.entries()].sort(([left], [right]) => left.localeCompare(right));
  }, [data.entries]);

  const knownUnits = data.entries.reduce((total, entry) => total + (entry.quantity != null && entry.unit === 'UN' ? entry.quantity : 0), 0);
  const knownMeters = data.entries.reduce((total, entry) => total + (entry.quantity != null && entry.unit === 'MT' ? entry.quantity : 0), 0);
  const pendingCount = data.entries.filter((entry) => entry.quantity == null).length;

  const persist = (next: WmsData, successMessage = 'Movimentação salva neste navegador.') => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      setData(next);
      setNotice(successMessage);
    } catch {
      setNotice('Não foi possível salvar os dados neste navegador.');
    }
  };

  const receiveStock = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const serials = inbound.mode === 'serialized' ? parseSerials(inbound.serials) : [];
    const quantity = inbound.mode === 'serialized' ? serials.length : Number(inbound.quantity);
    const boxCount = Number(inbound.boxCount);
    if (inbound.unit === 'MT' && inbound.mode === 'serialized') {
      setNotice('Itens serializados devem usar unidade UN.');
      return;
    }
    if (!isValidQuantity(quantity, inbound.unit) || !Number.isInteger(boxCount) || boxCount < 0) {
      setNotice('Confira a quantidade e o número de caixas informados.');
      return;
    }
    if (inbound.mode === 'serialized' && new Set(serials).size !== serials.length) {
      setNotice('Há números de série repetidos.');
      return;
    }
    const entry: InventoryEntry = {
      id: crypto.randomUUID(), location: inbound.location.trim().toUpperCase(),
      itemCode: inbound.itemCode.trim(), itemName: inbound.itemName.trim(), lot: inbound.lot.trim(),
      boxCount, quantity, rawQuantity: String(quantity), unit: inbound.unit, status: 'ARMAZENADO',
      serialized: inbound.mode === 'serialized', serials, supplier: inbound.supplier.trim(),
      invoiceNumber: inbound.invoiceNumber.trim(), receivedDate: inbound.receivedDate, barcode: '',
    };
    persist({ ...data, entries: [entry, ...data.entries] });
    setInbound({ ...inbound, itemCode: '', itemName: '', boxCount: '1', quantity: '1', serials: '' });
  };

  const resolveQuantity = (event: FormEvent<HTMLFormElement>, entry: InventoryEntry) => {
    event.preventDefault();
    const quantity = Number(new FormData(event.currentTarget).get('quantity'));
    if (!isValidQuantity(quantity, entry.unit)) {
      setNotice(`Informe uma quantidade válida em ${entry.unit}.`);
      return;
    }
    persist({
      ...data,
      entries: data.entries.map((current) => current.id === entry.id
        ? { ...current, quantity, rawQuantity: String(quantity), status: 'ARMAZENADO' }
        : current),
    });
    setNotice(`Quantidade do lote ${entry.lot} conferida e liberada.`);
  };

  const registerExistingSerials = (event: FormEvent<HTMLFormElement>, entryId: string) => {
    event.preventDefault();
    const entry = data.entries.find((current) => current.id === entryId);
    if (!entry || entry.quantity == null || entry.unit !== 'UN' || !Number.isInteger(entry.quantity)) return;
    const serials = parseSerials(serialInput);
    const existingSerials = new Set(data.entries.filter((current) => current.id !== entryId)
      .flatMap((current) => current.serials).map((serial) => serial.toLocaleUpperCase('pt-BR')));
    if (serials.length !== entry.quantity || new Set(serials.map((serial) => serial.toLocaleUpperCase('pt-BR'))).size !== serials.length) {
      setNotice(`Informe exatamente ${entry.quantity} seriais diferentes para este saldo.`);
      return;
    }
    if (serials.some((serial) => existingSerials.has(serial.toLocaleUpperCase('pt-BR')))) {
      setNotice('Um ou mais seriais já estão vinculados a outro saldo.');
      return;
    }
    persist({
      ...data,
      entries: data.entries.map((current) => current.id === entryId
        ? { ...current, serialized: true, serials, quantity: serials.length }
        : current),
    });
    setSerialEntryId('');
    setSerialInput('');
    setNotice(`Seriais vinculados ao SKU ${entry.itemCode}.`);
  };

  const registerMovement = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedEntry || selectedEntry.quantity == null || selectedEntry.quantity <= 0) {
      setNotice('Selecione uma linha com saldo conferido.');
      return;
    }
    if (!movementForm.reference.trim()) {
      setNotice('Informe o pedido, OS ou motivo da movimentação.');
      return;
    }
    const isTransfer = movementForm.kind === 'transferencia';
    const serials = isTransfer || !selectedEntry.serialized ? [] : parseSerials(movementForm.serials);
    const quantity = isTransfer ? selectedEntry.quantity
      : selectedEntry.serialized ? serials.length : Number(movementForm.quantity);
    if (!isValidQuantity(quantity, selectedEntry.unit) || quantity > selectedEntry.quantity) {
      setNotice(`Saldo disponível: ${formatQuantity(selectedEntry.quantity, selectedEntry.unit)}.`);
      return;
    }
    if (isTransfer && (!movementForm.destination.trim() || movementForm.destination.trim().toUpperCase() === selectedEntry.location)) {
      setNotice('Informe uma posição de destino diferente da origem.');
      return;
    }
    if (selectedEntry.serialized && !isTransfer && (
      new Set(serials).size !== serials.length || serials.some((serial) => !selectedEntry.serials.includes(serial))
    )) {
      setNotice('Use apenas seriais disponíveis nessa posição, sem repetição.');
      return;
    }

    const locationTo = isTransfer ? movementForm.destination.trim().toUpperCase() : '';
    const entries = data.entries.map((entry) => {
      if (entry.id !== selectedEntry.id) return entry;
      if (isTransfer) return { ...entry, location: locationTo };
      const remaining = selectedEntry.quantity! - quantity;
      return {
        ...entry,
        quantity: remaining,
        rawQuantity: String(remaining),
        boxCount: remaining === 0 ? 0 : entry.boxCount,
        serials: entry.serials.filter((serial) => !serials.includes(serial)),
        status: remaining === 0 ? 'BAIXADO' : entry.status,
      };
    });
    const movement: StockMovement = {
      id: crypto.randomUUID(), date: new Date().toISOString(), kind: movementForm.kind,
      itemCode: selectedEntry.itemCode, itemName: selectedEntry.itemName, lot: selectedEntry.lot,
      locationFrom: selectedEntry.location, locationTo, quantity, unit: selectedEntry.unit,
      reference: movementForm.reference.trim(), serials: isTransfer ? selectedEntry.serials : serials,
      wallBarcode: '', productionOrderCode: '',
    };
    persist({ entries, movements: [movement, ...data.movements] });
    setMovementForm({ ...movementForm, entryId: '', quantity: '1', destination: '', reference: '', serials: '' });
  };

  return (
    <div className="space-y-5">
      {initialView !== 'production' && <div className="flex gap-1 border-b border-gray-200" role="tablist" aria-label="WMS">
        <button type="button" role="tab" aria-selected={activeView === 'stock'} onClick={() => setActiveView('stock')} className={`inline-flex items-center gap-2 border-b-2 px-3.5 py-2 text-xs font-medium ${activeView === 'stock' ? 'border-blue-700 text-blue-700' : 'border-transparent text-gray-500 hover:text-slate-800'}`}><MapPin className="h-3.5 w-3.5" />Posições e estoque</button>
        <button type="button" role="tab" aria-selected={activeView === 'production'} onClick={() => setActiveView('production')} className={`inline-flex items-center gap-2 border-b-2 px-3.5 py-2 text-xs font-medium ${activeView === 'production' ? 'border-blue-700 text-blue-700' : 'border-transparent text-gray-500 hover:text-slate-800'}`}><Factory className="h-3.5 w-3.5" />Saída da produção</button>
      </div>}
      {initialView === 'production' || activeView === 'production' ? <ProductionIssuePanel data={data} onSave={persist} /> : <>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-lg border border-gray-200 bg-white p-3"><div className="text-xs text-gray-500">Saldo conferido</div><div className="mt-1 text-lg font-semibold text-slate-900">{formatQuantity(knownUnits, 'UN')}</div><div className="text-xs text-gray-400">Unidades</div></div>
        <div className="rounded-lg border border-gray-200 bg-white p-3"><div className="text-xs text-gray-500">Saldo em comprimento</div><div className="mt-1 text-lg font-semibold text-slate-900">{formatQuantity(knownMeters, 'MT')}</div><div className="text-xs text-gray-400">Metros</div></div>
        <div className="rounded-lg border border-gray-200 bg-white p-3"><div className="text-xs text-gray-500">Posições ocupadas</div><div className="mt-1 text-lg font-semibold text-slate-900">{positions.length}</div><div className="text-xs text-gray-400">Endereços distintos</div></div>
        <div className={`rounded-lg border p-3 ${pendingCount ? 'border-amber-200 bg-amber-50' : 'border-gray-200 bg-white'}`}><div className="text-xs text-gray-500">Quantidades para conferir</div><div className={`mt-1 text-lg font-semibold ${pendingCount ? 'text-amber-700' : 'text-slate-900'}`}>{pendingCount}</div><div className="text-xs text-gray-400">Não entram no saldo disponível</div></div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <form onSubmit={receiveStock} className="space-y-3 rounded-lg border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2 border-b border-gray-100 pb-3"><PackagePlus className="h-4 w-4 text-emerald-700" /><h2 className="text-sm font-semibold text-slate-900">Entrada / recebimento</h2></div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="text-xs font-medium text-gray-600">Posição (endereço)<input required value={inbound.location} onChange={(e) => setInbound({ ...inbound, location: e.target.value })} placeholder="A002000110" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Lote / recebimento<input required value={inbound.lot} onChange={(e) => setInbound({ ...inbound, lot: e.target.value })} placeholder="REC463099700" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">SKU<input required value={inbound.itemCode} onChange={(e) => setInbound({ ...inbound, itemCode: e.target.value })} placeholder="9700" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Item<input required value={inbound.itemName} onChange={(e) => setInbound({ ...inbound, itemName: e.target.value })} placeholder="CAIXA 3D - 8410" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Unidade<select value={inbound.unit} onChange={(e) => setInbound({ ...inbound, unit: e.target.value as Unit })} className="mt-1 w-full rounded border border-gray-300 bg-white px-2.5 py-2 text-sm"><option value="UN">UN</option><option value="MT">MT</option></select></label>
            <label className="text-xs font-medium text-gray-600">Controle<select value={inbound.mode} onChange={(e) => setInbound({ ...inbound, mode: e.target.value as 'quantity' | 'serialized' })} className="mt-1 w-full rounded border border-gray-300 bg-white px-2.5 py-2 text-sm"><option value="quantity">Por quantidade</option><option value="serialized">Serializado</option></select></label>
            {inbound.mode === 'quantity' ? <label className="text-xs font-medium text-gray-600">Quantidade recebida<input required type="number" min="0.001" step={inbound.unit === 'MT' ? '0.001' : '1'} value={inbound.quantity} onChange={(e) => setInbound({ ...inbound, quantity: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label> : <label className="text-xs font-medium text-gray-600 sm:col-span-2">Seriais recebidos<textarea required rows={3} value={inbound.serials} onChange={(e) => setInbound({ ...inbound, serials: e.target.value })} placeholder="Um serial por linha ou separados por vírgula" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /><span className="mt-1 block font-normal text-gray-400">Quantidade: {parseSerials(inbound.serials).length} serial(is)</span></label>}
            <label className="text-xs font-medium text-gray-600">Quantidade de caixas<input required type="number" min="0" step="1" value={inbound.boxCount} onChange={(e) => setInbound({ ...inbound, boxCount: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Fornecedor (opcional)<input value={inbound.supplier} onChange={(e) => setInbound({ ...inbound, supplier: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Nota fiscal (opcional)<input value={inbound.invoiceNumber} onChange={(e) => setInbound({ ...inbound, invoiceNumber: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
            <label className="text-xs font-medium text-gray-600">Data do recebimento (opcional)<input type="date" value={inbound.receivedDate} onChange={(e) => setInbound({ ...inbound, receivedDate: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
          </div>
          <button type="submit" className="inline-flex items-center gap-2 rounded bg-emerald-700 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-800"><ArrowDownToLine className="h-3.5 w-3.5" />Registrar entrada</button>
        </form>

        <form onSubmit={registerMovement} className="space-y-3 rounded-lg border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2 border-b border-gray-100 pb-3"><ClipboardMinus className="h-4 w-4 text-rose-700" /><h2 className="text-sm font-semibold text-slate-900">Baixa ou transferência</h2></div>
          <label className="block text-xs font-medium text-gray-600">Tipo de movimentação<select value={movementForm.kind} onChange={(e) => setMovementForm({ ...movementForm, kind: e.target.value as MovementKind, destination: '', serials: '' })} className="mt-1 w-full rounded border border-gray-300 bg-white px-2.5 py-2 text-sm"><option value="baixa">Baixa de estoque</option><option value="transferencia">Transferência de posição</option></select></label>
          <label className="block text-xs font-medium text-gray-600">Posição · lote · SKU · saldo<select required value={movementForm.entryId} onChange={(e) => setMovementForm({ ...movementForm, entryId: e.target.value, serials: '', quantity: '1' })} className="mt-1 w-full rounded border border-gray-300 bg-white px-2.5 py-2 text-sm"><option value="">Selecione um saldo conferido</option>{data.entries.filter((entry) => entry.quantity != null && entry.quantity > 0).map((entry) => <option key={entry.id} value={entry.id}>{entry.location} · {entry.lot} · {entry.itemCode} {entry.itemName} · {formatQuantity(entry.quantity!, entry.unit)}</option>)}</select></label>
          {selectedEntry && movementForm.kind === 'baixa' && (selectedEntry.serialized ? <label className="block text-xs font-medium text-gray-600">Números de série<textarea required rows={3} value={movementForm.serials} onChange={(e) => setMovementForm({ ...movementForm, serials: e.target.value })} placeholder="Seriais que sairão do estoque" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /><span className="mt-1 block font-normal text-gray-400">Disponíveis: {selectedEntry.serials.join(', ')}</span></label> : <label className="block text-xs font-medium text-gray-600">Quantidade para baixa (saldo: {formatQuantity(selectedEntry.quantity!, selectedEntry.unit)})<input required type="number" min="0.001" max={selectedEntry.quantity!} step={selectedEntry.unit === 'MT' ? '0.001' : '1'} value={movementForm.quantity} onChange={(e) => setMovementForm({ ...movementForm, quantity: e.target.value })} className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>)}
          {selectedEntry && movementForm.kind === 'transferencia' && <><label className="block text-xs font-medium text-gray-600">Nova posição<input required value={movementForm.destination} onChange={(e) => setMovementForm({ ...movementForm, destination: e.target.value })} placeholder="A004000110" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 font-mono text-sm" /></label><p className="rounded bg-blue-50 p-2.5 text-xs text-blue-900">A transferência move a linha inteira para preservar a quantidade de caixas e a rastreabilidade do lote: {formatQuantity(selectedEntry.quantity!, selectedEntry.unit)}.</p></>}
          <label className="block text-xs font-medium text-gray-600">Pedido, OS ou motivo<input required value={movementForm.reference} onChange={(e) => setMovementForm({ ...movementForm, reference: e.target.value })} placeholder="Ex.: OP-2026-0042" className="mt-1 w-full rounded border border-gray-300 px-2.5 py-2 text-sm" /></label>
          <button type="submit" disabled={!selectedEntry} className="inline-flex items-center gap-2 rounded bg-rose-700 px-3 py-2 text-xs font-semibold text-white hover:bg-rose-800 disabled:cursor-not-allowed disabled:opacity-50">{movementForm.kind === 'baixa' ? <><ClipboardMinus className="h-3.5 w-3.5" />Registrar baixa</> : <><ArrowLeftRight className="h-3.5 w-3.5" />Transferir posição</>}</button>
        </form>
      </div>

      {notice && <div role="status" className="border-l-4 border-blue-600 bg-blue-50 px-3 py-2 text-xs text-blue-900">{notice}</div>}

      <section className="overflow-hidden rounded-lg border border-gray-200 bg-white">
        <div className="border-b border-gray-100 px-4 py-3"><div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-gray-500" /><h2 className="text-sm font-semibold text-slate-900">Saldo por posição</h2></div></div>
        <div className="overflow-x-auto"><table className="w-full min-w-[650px] text-left text-xs"><thead><tr className="border-b border-gray-100 bg-slate-50 text-gray-500"><th className="px-4 py-2 font-medium">Endereço</th><th className="px-4 py-2 text-right font-medium">Registros</th><th className="px-4 py-2 text-right font-medium">Caixas</th><th className="px-4 py-2 text-right font-medium">Saldo UN</th><th className="px-4 py-2 text-right font-medium">Saldo MT</th><th className="px-4 py-2 text-right font-medium">A conferir</th></tr></thead><tbody className="divide-y divide-gray-50">{positions.map(([location, summary]) => <tr key={location}><td className="px-4 py-2.5 font-mono font-semibold text-slate-800">{location}</td><td className="px-4 py-2.5 text-right">{summary.rows}</td><td className="px-4 py-2.5 text-right">{summary.boxes}</td><td className="px-4 py-2.5 text-right">{formatQuantity(summary.units, 'UN')}</td><td className="px-4 py-2.5 text-right">{formatQuantity(summary.meters, 'MT')}</td><td className="px-4 py-2.5 text-right">{summary.pending || '—'}</td></tr>)}</tbody></table></div>
      </section>

      <section className="overflow-hidden rounded-lg border border-gray-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 px-4 py-3"><div className="flex items-center gap-2"><Boxes className="h-4 w-4 text-gray-500" /><h2 className="text-sm font-semibold text-slate-900">Estoque por lote e endereço</h2></div><div className="relative w-full sm:w-80"><Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Posição, SKU, item ou lote" className="w-full rounded border border-gray-300 py-1.5 pl-8 pr-2 text-xs" /></div></div>
        <div className="overflow-x-auto"><table className="w-full min-w-[1050px] text-left text-xs"><thead><tr className="border-b border-gray-100 bg-slate-50 text-gray-500"><th className="px-3 py-2 font-medium">Posição</th><th className="px-3 py-2 font-medium">SKU / Item</th><th className="px-3 py-2 font-medium">Lote</th><th className="px-3 py-2 text-right font-medium">Caixas</th><th className="px-3 py-2 text-right font-medium">Saldo</th><th className="px-3 py-2 font-medium">Status / recebimento</th><th className="px-3 py-2 font-medium">Ação</th></tr></thead>
          <tbody className="divide-y divide-gray-50">{filteredEntries.map((entry) => <tr key={entry.id} className="align-top hover:bg-slate-50"><td className="px-3 py-2.5 font-mono font-semibold text-slate-700">{entry.location}</td><td className="px-3 py-2.5"><div className="font-semibold text-slate-800">{entry.itemName}</div><div className="text-gray-400">SKU {entry.itemCode}</div>{entry.serialized && <div className="mt-1 text-[11px] text-blue-700">Serializado · {entry.serials.length} disponível(is)</div>}</td><td className="px-3 py-2.5 font-mono text-slate-700">{entry.lot}</td><td className="px-3 py-2.5 text-right">{entry.boxCount}</td><td className="px-3 py-2.5 text-right font-semibold">{entry.quantity == null ? <span className="text-amber-700">Conferir: {entry.rawQuantity}</span> : formatQuantity(entry.quantity, entry.unit)}</td><td className="px-3 py-2.5"><div>{entry.status}</div>{(entry.supplier || entry.invoiceNumber || entry.receivedDate) && <div className="mt-1 text-gray-400">{[entry.supplier, entry.invoiceNumber && `NF ${entry.invoiceNumber}`, entry.receivedDate].filter(Boolean).join(' · ')}</div>}{entry.quantity == null && <div className="mt-1 text-amber-700">Bloqueado para movimentação até conferência</div>}</td><td className="px-3 py-2.5">{entry.quantity == null ? <form onSubmit={(event) => resolveQuantity(event, entry)} className="flex items-center gap-1"><input name="quantity" required type="number" min="0.001" step={entry.unit === 'MT' ? '0.001' : '1'} placeholder={`Qtd ${entry.unit}`} className="w-24 rounded border border-gray-300 px-2 py-1" /><button className="rounded bg-amber-600 px-2 py-1 font-semibold text-white hover:bg-amber-700">Conferir</button></form> : entry.unit === 'UN' && !entry.serialized ? serialEntryId === entry.id ? <form onSubmit={(event) => registerExistingSerials(event, entry.id)} className="min-w-56 space-y-1"><textarea required rows={3} value={serialInput} onChange={(event) => setSerialInput(event.target.value)} placeholder={`Informe ${entry.quantity} seriais`} className="w-full rounded border border-gray-300 px-2 py-1 font-mono" /><div className="flex gap-1"><button className="rounded bg-blue-700 px-2 py-1 font-semibold text-white">Vincular ({parseSerials(serialInput).length}/{entry.quantity})</button><button type="button" onClick={() => { setSerialEntryId(''); setSerialInput(''); }} className="rounded border border-gray-300 px-2 py-1">Cancelar</button></div></form> : <button type="button" onClick={() => { setSerialEntryId(entry.id); setSerialInput(''); }} className="rounded border border-blue-200 px-2 py-1 font-medium text-blue-700 hover:bg-blue-50">Vincular seriais</button> : <span className="text-blue-700">Rastreado por serial</span>}</td></tr>)}
          {filteredEntries.length === 0 && <tr><td colSpan={7} className="px-4 py-8 text-center text-gray-500">Nenhum registro encontrado.</td></tr>}</tbody>
        </table></div>
      </section>

      <section className="overflow-hidden rounded-lg border border-gray-200 bg-white">
        <div className="flex items-center gap-2 border-b border-gray-100 px-4 py-3"><Barcode className="h-4 w-4 text-gray-500" /><h2 className="text-sm font-semibold text-slate-900">Histórico de movimentações</h2></div>
        {data.movements.length ? <div className="overflow-x-auto"><table className="w-full min-w-[950px] text-left text-xs"><thead><tr className="border-b border-gray-100 bg-slate-50 text-gray-500"><th className="px-3 py-2 font-medium">Data</th><th className="px-3 py-2 font-medium">Movimento</th><th className="px-3 py-2 font-medium">SKU / Item</th><th className="px-3 py-2 font-medium">Lote</th><th className="px-3 py-2 font-medium">Origem</th><th className="px-3 py-2 font-medium">Destino / saldo</th><th className="px-3 py-2 text-right font-medium">Quantidade</th><th className="px-3 py-2 font-medium">Referência / seriais</th></tr></thead><tbody className="divide-y divide-gray-50">{data.movements.map((movement) => <tr key={movement.id}><td className="whitespace-nowrap px-3 py-2.5 text-gray-500">{new Date(movement.date).toLocaleString('pt-BR')}</td><td className="px-3 py-2.5">{movement.kind === 'saida_producao' ? 'Saída da produção' : movement.kind === 'baixa' ? 'Baixa' : 'Transferência'}</td><td className="px-3 py-2.5">{movement.itemCode} · {movement.itemName}</td><td className="px-3 py-2.5 font-mono">{movement.lot}</td><td className="px-3 py-2.5 font-mono">{movement.locationFrom || '—'}</td><td className="px-3 py-2.5 font-mono">{movement.kind === 'transferencia' ? movement.locationTo : movement.kind === 'saida_producao' ? 'PRODUÇÃO' : '—'}</td><td className="px-3 py-2.5 text-right font-semibold">{formatQuantity(movement.quantity, movement.unit)}</td><td className="px-3 py-2.5">{movement.productionOrderCode || movement.reference}{movement.wallBarcode && <div className="font-mono text-gray-400">Parede: {movement.wallBarcode}</div>}{movement.serials.length > 0 && <div className="font-mono text-gray-400">{movement.serials.join(', ')}</div>}</td></tr>)}</tbody></table></div> : <p className="px-4 py-5 text-xs text-gray-500">As entradas, baixas e transferências aparecerão aqui.</p>}
      </section>
      </>}
    </div>
  );
}