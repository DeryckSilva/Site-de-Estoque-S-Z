export interface WmsSeedEntry {
  location: string;
  sku: string;
  itemName: string;
  boxCount: number;
  quantity: number | null;
  rawQuantity: string;
  unit: 'UN' | 'MT';
  lot: string;
  status: string;
}

export const WMS_INITIAL_STOCK: WmsSeedEntry[] = [
  { location: 'A001000100', sku: '1805', itemName: 'IMÃ 18x5 N35', boxCount: 1, quantity: null, rawQuantity: '1326 - 30', unit: 'UN', lot: 'REC463081805', status: 'ARMAZENADO' },
  { location: 'A001000100', sku: '1805', itemName: 'IMÃ 18x5 N35', boxCount: 1, quantity: 82, rawQuantity: '82', unit: 'UN', lot: 'REC463081805', status: 'ARMAZENADO' },
  { location: 'A001000100', sku: '2006', itemName: 'IMÃ 20x6 N35', boxCount: 1, quantity: 67, rawQuantity: '67', unit: 'UN', lot: 'REC463082006', status: 'ARMAZENADO' },
  { location: 'A004000110', sku: '5100', itemName: 'FONTE CARREGADOR', boxCount: 1, quantity: 96, rawQuantity: '96', unit: 'UN', lot: 'REC463085100', status: 'ARMAZENADO' },
  { location: 'A004000110', sku: '5100', itemName: 'FONTE CARREGADOR', boxCount: 1, quantity: 62, rawQuantity: '62', unit: 'UN', lot: 'REC463085100', status: 'ARMAZENADO' },
  { location: 'A004000110', sku: '5100', itemName: 'FONTE CARREGADOR', boxCount: 1, quantity: null, rawQuantity: '39 - 1', unit: 'UN', lot: 'REC463085100', status: 'ARMAZENADO' },
  { location: 'A006000120', sku: '1484', itemName: 'ST-8410 4G', boxCount: 4, quantity: 200, rawQuantity: '200', unit: 'UN', lot: 'REC463081484', status: 'ARMAZENADO' },
  { location: 'A006000120', sku: '1484', itemName: 'ST-8410 4G', boxCount: 1, quantity: 165, rawQuantity: '165', unit: 'UN', lot: 'REC463081484', status: 'ARMAZENADO' },
  { location: 'A008000120', sku: '9500', itemName: 'MALETA PERSONALIZÁVEL', boxCount: 1, quantity: 5, rawQuantity: '5', unit: 'UN', lot: 'REC463099500', status: 'ARMAZENADO' },
  { location: 'A002000110', sku: '9700', itemName: 'CAIXA 3D - 8410', boxCount: 1, quantity: 215, rawQuantity: '215', unit: 'UN', lot: 'REC463099700', status: 'ARMAZENADO' },
];